# COMP308-W2017-Lesson6A

## Welcome to Lesson 6 - Authentication with Passport

please use **`npm install`** to install project dependencies
