module.exports = {
  //local MongoDB deployment ->
  "URI": "mongodb://localhost/videogames"
  //Remote MongoDB deployment -> let URI = "mongodb://thomas:123456@ds054999.mlab.com:54999/videogames";
};
