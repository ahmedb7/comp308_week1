# COMP308-W2017-Lesson4A

## Welcome to Lesson 4 - Intro to MongoDB

please use **`npm install`** to install project dependencies
